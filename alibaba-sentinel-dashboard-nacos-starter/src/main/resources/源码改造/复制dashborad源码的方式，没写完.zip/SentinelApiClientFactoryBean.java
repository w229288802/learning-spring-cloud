package cn.appnx.sentinel;

import com.alibaba.nacos.api.config.ConfigService;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

public class SentinelApiClientFactoryBean implements FactoryBean {

    private ConfigService configService;

    public SentinelApiClientFactoryBean(ConfigService configService) {
        this.configService = configService;
    }


    @Override
    public Object getObject() throws Exception {
        Enhancer enhancer = new Enhancer();
        try {
            enhancer.setSuperclass(Class.forName("com.alibaba.csp.sentinel.dashboard.client.SentinelApiClient"));
            enhancer.setCallback(new MethodInterceptor() {
                @Override
                public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
                    // 添加代理逻辑
                    return proxy.invokeSuper(obj, args);
                }
            });
            return enhancer.create();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Class<?> getObjectType() {
        try {
            return Class.forName("com.alibaba.csp.sentinel.dashboard.client.SentinelApiClient");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
