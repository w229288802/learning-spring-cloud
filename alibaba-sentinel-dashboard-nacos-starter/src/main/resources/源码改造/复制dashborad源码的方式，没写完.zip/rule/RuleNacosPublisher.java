package cn.appnx.sentinel.rule;

import cn.appnx.sentinel.datasource.entity.rule.RuleEntity;
import com.alibaba.csp.sentinel.datasource.Converter;
import com.alibaba.csp.sentinel.util.AssertUtil;
import com.alibaba.nacos.api.config.ConfigService;
import com.alibaba.nacos.api.config.listener.AbstractListener;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Future;

public abstract class RuleNacosPublisher<T extends RuleEntity> implements DynamicRulePublisher<List<T>> {

    @Autowired
    protected ConfigService configService;
    @Autowired
    protected Converter<List<T>, String> converter;

    public static Map<String, Future<String>> futureMap = new ConcurrentHashMap<>();

    @Override
    public void publish(String app, List<T> rules) throws Exception {
        AssertUtil.notEmpty(app, "app name cannot be empty");
        if (rules == null) {
            return;
        }
        CompletableFuture<String> future = new CompletableFuture<>();
        futureMap.put(app + getDataIdPostfix() + NacosConfigUtil.GROUP_ID, future);
        configService.addListener(app + getDataIdPostfix(), NacosConfigUtil.GROUP_ID, new AbstractListener() {

            @Override
            public void receiveConfigInfo(String configInfo) {
                future.complete(configInfo);
            }
        });
        configService.publishConfig(app + getDataIdPostfix(),
                NacosConfigUtil.GROUP_ID, converter.convert(rules));
    }
    /**
     * 文件后缀 参考 com.alibaba.csp.sentinel.dashboard.rule.nacos.NacosConfigUtil.FLOW_DATA_ID_POSTFIX
     * @return
     */
    public abstract String getDataIdPostfix();
}
