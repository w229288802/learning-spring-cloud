package cn.appnx.sentinel.rule.system;

import cn.appnx.sentinel.datasource.entity.rule.SystemRuleEntity;
import cn.appnx.sentinel.rule.NacosConfigUtil;
import cn.appnx.sentinel.rule.RuleNacosPublisher;
import org.springframework.stereotype.Component;

@Component("systemRuleNacosPublisher")
public class SystemRuleNacosPublisher  extends RuleNacosPublisher<SystemRuleEntity> {
    @Override
    public String getDataIdPostfix() {
        return NacosConfigUtil.SYSTEM_DATA_ID_POSTFIX;
    }
}
