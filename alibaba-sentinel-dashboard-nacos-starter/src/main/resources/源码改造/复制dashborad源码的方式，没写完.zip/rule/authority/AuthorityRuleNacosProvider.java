package cn.appnx.sentinel.rule.authority;

import cn.appnx.sentinel.datasource.entity.rule.AuthorityRuleEntity;
import cn.appnx.sentinel.rule.NacosConfigUtil;
import cn.appnx.sentinel.rule.RuleNacosProvider;
import org.springframework.stereotype.Component;

@Component("authorityRuleNacosProvider")
public class AuthorityRuleNacosProvider extends RuleNacosProvider<AuthorityRuleEntity> {
    @Override
    public String getDataIdPostfix() {
        return NacosConfigUtil.AUTHORITY_DATA_ID_POSTFIX;
    }
}
