package cn.appnx.sentinel.rule.authority;

import cn.appnx.sentinel.datasource.entity.rule.AuthorityRuleEntity;
import cn.appnx.sentinel.rule.NacosConfigUtil;
import cn.appnx.sentinel.rule.RuleNacosPublisher;
import org.springframework.stereotype.Component;

@Component("authorityRuleNacosPublisher")
public class AuthorityRuleNacosPublisher extends RuleNacosPublisher<AuthorityRuleEntity> {

    @Override
    public String getDataIdPostfix() {
        return NacosConfigUtil.AUTHORITY_DATA_ID_POSTFIX;
    }
}