package com.alibaba.csp.sentinel.dashboard.controller.nacos;

import com.alibaba.csp.sentinel.dashboard.client.SentinelApiClient;
import com.alibaba.csp.sentinel.dashboard.datasource.entity.gateway.ApiDefinitionEntity;
import com.alibaba.csp.sentinel.dashboard.datasource.entity.gateway.GatewayFlowRuleEntity;
import com.alibaba.csp.sentinel.dashboard.datasource.entity.rule.*;
import com.alibaba.csp.sentinel.dashboard.rule.DynamicRuleProvider;
import com.alibaba.csp.sentinel.dashboard.rule.DynamicRulePublisher;

import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class SentinelApiClientWrapper extends SentinelApiClient {

    @Resource(name = "flowRuleNacosProvider")
    private DynamicRuleProvider<List<FlowRuleEntity>> flowRuleNacosProvider;
    @Resource(name = "flowRuleNacosPublisher")
    private DynamicRulePublisher<List<FlowRuleEntity>> flowRuleNacosPublisher;

    @Resource(name = "degradeRuleNacosProvider")
    private DynamicRuleProvider<List<DegradeRuleEntity>> degradeRuleNacosProvider;
    @Resource(name = "degradeRuleNacosPublisher")
    private DynamicRulePublisher<List<DegradeRuleEntity>> degradeRuleNacosPublisher;

    @Resource(name = "paramFlowFlowRuleNacosProvider")
    private DynamicRuleProvider<List<ParamFlowRuleEntity>> paramFlowFlowRuleNacosProvider;
    @Resource(name = "paramFlowFlowRuleNacosPublisher")
    private DynamicRulePublisher<List<ParamFlowRuleEntity>> paramFlowFlowRuleNacosPublisher;

    @Resource(name = "systemRuleNacosProvider")
    private DynamicRuleProvider<List<SystemRuleEntity>> systemRuleNacosProvider;
    @Resource(name = "systemRuleNacosPublisher")
    private DynamicRulePublisher<List<SystemRuleEntity>> systemRuleNacosPublisher;

    @Resource(name = "authorityRuleNacosProvider")
    private DynamicRuleProvider<List<AuthorityRuleEntity>> authorityRuleNacosProvider;
    @Resource(name = "authorityRuleNacosPublisher")
    private DynamicRulePublisher<List<AuthorityRuleEntity>> authorityRuleNacosPublisher;

    @Resource(name = "apiDefinitionNacosProvider")
    private DynamicRuleProvider<List<ApiDefinitionEntity>> apiDefinitionNacosProvider;
    @Resource(name = "apiDefinitionNacosPublisher")
    private DynamicRulePublisher<List<ApiDefinitionEntity>> apiDefinitionNacosPublisher;

    @Resource(name = "gatewayFlowFlowRuleNacosProvider")
    private DynamicRuleProvider<List<GatewayFlowRuleEntity>> gatewayFlowFlowRuleNacosProvider;
    @Resource(name = "gatewayFlowFlowRuleNacosPublisher")
    private DynamicRulePublisher<List<GatewayFlowRuleEntity>> gatewayFlowFlowRuleNacosPublisher;

    @Override
    public CompletableFuture<Void> setFlowRuleOfMachineAsync(String app, String ip, int port, List<FlowRuleEntity> rules) {
        return CompletableFuture.runAsync(()->{
            try {
                flowRuleNacosPublisher.publish(app, rules);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }

    @Override
    public List<FlowRuleEntity> fetchFlowRuleOfMachine(String app, String ip, int port) {
        try {
            return flowRuleNacosProvider.getRules(app);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean setDegradeRuleOfMachine(String app, String ip, int port, List<DegradeRuleEntity> rules) {
        try {
            degradeRuleNacosPublisher.publish(app, rules);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return true;
    }

    @Override
    public List<DegradeRuleEntity> fetchDegradeRuleOfMachine(String app, String ip, int port) {
        try {
            return degradeRuleNacosProvider.getRules(app);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public CompletableFuture<Void> setParamFlowRuleOfMachine(String app, String ip, int port, List<ParamFlowRuleEntity> rules) {
        return CompletableFuture.runAsync(()->{
            try {
                paramFlowFlowRuleNacosPublisher.publish(app, rules);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }

    @Override
    public CompletableFuture<List<ParamFlowRuleEntity>> fetchParamFlowRulesOfMachine(String app, String ip, int port) {
        return CompletableFuture.supplyAsync(()->{
            try {
                return paramFlowFlowRuleNacosProvider.getRules(app);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }

    @Override
    public boolean setSystemRuleOfMachine(String app, String ip, int port, List<SystemRuleEntity> rules) {
        try {
            systemRuleNacosPublisher.publish(app, rules);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return true;
    }

    @Override
    public List<SystemRuleEntity> fetchSystemRuleOfMachine(String app, String ip, int port) {
        try {
            return systemRuleNacosProvider.getRules(app);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean setAuthorityRuleOfMachine(String app, String ip, int port, List<AuthorityRuleEntity> rules) {
        try {
            authorityRuleNacosPublisher.publish(app, rules);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return true;
    }

    @Override
    public List<AuthorityRuleEntity> fetchAuthorityRulesOfMachine(String app, String ip, int port) {
        try {
            return authorityRuleNacosProvider.getRules(app);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean modifyApis(String app, String ip, int port, List<ApiDefinitionEntity> apis) {
        try {
            apiDefinitionNacosPublisher.publish(app, apis);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return true;
    }

    @Override
    public CompletableFuture<List<ApiDefinitionEntity>> fetchApis(String app, String ip, int port) {
        return CompletableFuture.supplyAsync(()->{
            try {
                return apiDefinitionNacosProvider.getRules(app);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }

    @Override
    public boolean modifyGatewayFlowRules(String app, String ip, int port, List<GatewayFlowRuleEntity> rules) {
        try {
            gatewayFlowFlowRuleNacosPublisher.publish(app, rules);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return true;
    }

    @Override
    public CompletableFuture<List<GatewayFlowRuleEntity>> fetchGatewayFlowRules(String app, String ip, int port) {
        return CompletableFuture.supplyAsync(()->{
            try {
                return gatewayFlowFlowRuleNacosProvider.getRules(app);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}
