package com.alibaba.csp.sentinel.dashboard.rule.nacos;

import com.alibaba.csp.sentinel.dashboard.datasource.entity.rule.RuleEntity;
import com.alibaba.csp.sentinel.dashboard.rule.DynamicRuleProvider;
import com.alibaba.csp.sentinel.datasource.Converter;
import com.alibaba.csp.sentinel.util.StringUtil;
import com.alibaba.nacos.api.config.ConfigService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public abstract class RuleNacosProvider <T extends RuleEntity>  implements DynamicRuleProvider<List<T>> {

    private final Logger logger = LoggerFactory.getLogger(RuleNacosProvider.class);


    @Autowired
    protected ConfigService configService;
    @Autowired
    protected Converter<String, List<T>> converter;

    @Override
    public List<T> getRules(String appName) throws Exception {

        String rules = null;
        Future<String> future = RuleNacosPublisher.futureMap.get(appName + getDataIdPostfix() + NacosConfigUtil.GROUP_ID);
        if(future!=null) {
            try {
                rules = future.get(3000, TimeUnit.SECONDS);
            }  catch (Exception e) {
                logger.error("getRules error", e);
            }
        }
        if (StringUtil.isEmpty(rules)){
            rules = configService.getConfig(appName + getDataIdPostfix(),
                    NacosConfigUtil.GROUP_ID, 3000);
        }

        if (StringUtil.isEmpty(rules)) {
            return new ArrayList<>();
        }
        return converter.convert(rules);
    }

    /**
     * 文件后缀 参考 com.alibaba.csp.sentinel.dashboard.rule.nacos.NacosConfigUtil.FLOW_DATA_ID_POSTFIX
     * @return
     */
    public abstract String getDataIdPostfix();
}
